/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package integrativeproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ADMIN-PC
 */
public class Report extends javax.swing.JFrame {
    
    String databaseURL = "jdbc:mysql://localhost:3306/inventory";
    String userData = "root";
    String pass = "Dharr12345";

    /**
     * Creates new form Report
     */
    public Report() {
        initComponents();
        available();
        assigned();
        input();
        output();
        employee();
    }
    
    public void available() {
        Connection conn;
        DefaultTableModel tblModel = (DefaultTableModel)available.getModel();
        try {
            conn = DriverManager.getConnection(databaseURL,userData,pass);
            PreparedStatement pst = conn.prepareStatement("select count(peripheral) as peripheral from ITEMS where availability = " + "\"" + "available" + "\"");
            ResultSet rs = pst.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();

            int q = stData.getColumnCount();

            
            tblModel.setRowCount(0);

            while (rs.next()) {
                Vector columnData = new Vector();

                for (int i = 1; i <= q; i++) {
                    
                    columnData.add(rs.getString("PERIPHERAL"));
                    
                }
                tblModel.addRow(columnData);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }

    }
    
    public void assigned() {
        Connection conn;
        DefaultTableModel tblModel = (DefaultTableModel)assigned.getModel();
        try {
            conn = DriverManager.getConnection(databaseURL,userData,pass);
            PreparedStatement pst = conn.prepareStatement("select count(peripheral) as peripheral from ITEMS");
            ResultSet rs = pst.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();

            int q = stData.getColumnCount();

            
            tblModel.setRowCount(0);

            while (rs.next()) {
                Vector columnData = new Vector();

                for (int i = 1; i <= q; i++) {
                    
                    columnData.add(rs.getString("PERIPHERAL"));
                    
                }
                tblModel.addRow(columnData);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }

    }
    
    public void input() {
        Connection conn;
        DefaultTableModel tblModel = (DefaultTableModel)input.getModel();
        try {
            conn = DriverManager.getConnection(databaseURL,userData,pass);
            PreparedStatement pst = conn.prepareStatement("select count(peripheral) as peripheral from ITEMS where io = " + "\"" + "input" + "\"");
            ResultSet rs = pst.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();

            int q = stData.getColumnCount();

            
            tblModel.setRowCount(0);

            while (rs.next()) {
                Vector columnData = new Vector();

                for (int i = 1; i <= q; i++) {
                    
                    columnData.add(rs.getString("PERIPHERAL"));
                    
                }
                tblModel.addRow(columnData);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }

    }
    
    public void output() {
        Connection conn;
        DefaultTableModel tblModel = (DefaultTableModel)output.getModel();
        try {
            conn = DriverManager.getConnection(databaseURL,userData,pass);
            PreparedStatement pst = conn.prepareStatement("select count(peripheral) as peripheral from ITEMS where io = " + "\"" + "output" + "\"");
            ResultSet rs = pst.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();

            int q = stData.getColumnCount();

            
            tblModel.setRowCount(0);

            while (rs.next()) {
                Vector columnData = new Vector();

                for (int i = 1; i <= q; i++) {
                    
                    columnData.add(rs.getString("PERIPHERAL"));
                    
                }
                tblModel.addRow(columnData);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }

    }
    
    public void employee() {
        Connection conn;
        DefaultTableModel tblModel = (DefaultTableModel)employees.getModel();
        try {
            conn = DriverManager.getConnection(databaseURL,userData,pass);
            PreparedStatement pst = conn.prepareStatement("select count(employee) as employee from ITEMS where employee like " + "\"" + "%" + "\"");
            ResultSet rs = pst.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();

            int q = stData.getColumnCount();

            
            tblModel.setRowCount(0);

            while (rs.next()) {
                Vector columnData = new Vector();

                for (int i = 1; i <= q; i++) {
                    
                    columnData.add(rs.getString("EMPLOYEE"));
                    
                }
                tblModel.addRow(columnData);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }

    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        available = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        assigned = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        output = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        input = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        employees = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(700, 500));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));

        jScrollPane1.setBackground(new java.awt.Color(0, 0, 0));
        jScrollPane1.setForeground(new java.awt.Color(255, 255, 255));

        available.setBackground(new java.awt.Color(0, 0, 0));
        available.setFont(new java.awt.Font("Bookman Old Style", 1, 14)); // NOI18N
        available.setForeground(new java.awt.Color(255, 255, 255));
        available.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Number of available peripherals"
            }
        ));
        jScrollPane1.setViewportView(available);

        jScrollPane3.setBackground(new java.awt.Color(0, 0, 0));
        jScrollPane3.setForeground(new java.awt.Color(255, 255, 255));

        assigned.setBackground(new java.awt.Color(0, 0, 0));
        assigned.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        assigned.setForeground(new java.awt.Color(255, 255, 255));
        assigned.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Number of assigned Peripherals"
            }
        ));
        jScrollPane3.setViewportView(assigned);

        jScrollPane4.setBackground(new java.awt.Color(0, 0, 0));
        jScrollPane4.setForeground(new java.awt.Color(255, 255, 255));

        output.setBackground(new java.awt.Color(0, 0, 0));
        output.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        output.setForeground(new java.awt.Color(255, 255, 255));
        output.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Number of output Peripherals"
            }
        ));
        jScrollPane4.setViewportView(output);

        jScrollPane5.setBackground(new java.awt.Color(0, 0, 0));
        jScrollPane5.setForeground(new java.awt.Color(255, 255, 255));

        input.setBackground(new java.awt.Color(0, 0, 0));
        input.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        input.setForeground(new java.awt.Color(255, 255, 255));
        input.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Number of input Peripherals"
            }
        ));
        jScrollPane5.setViewportView(input);

        jScrollPane6.setBackground(new java.awt.Color(0, 0, 0));
        jScrollPane6.setForeground(new java.awt.Color(255, 255, 255));

        employees.setBackground(new java.awt.Color(0, 0, 0));
        employees.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        employees.setForeground(new java.awt.Color(255, 255, 255));
        employees.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Number of employees with peripherals"
            }
        ));
        jScrollPane6.setViewportView(employees);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 613, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 613, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 613, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 613, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 613, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(48, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 700, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(3, 3, 3)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGap(4, 4, 4)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Report.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Report().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable assigned;
    private javax.swing.JTable available;
    private javax.swing.JTable employees;
    private javax.swing.JTable input;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTable output;
    // End of variables declaration//GEN-END:variables
}
